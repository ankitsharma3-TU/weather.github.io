<template>
  <div class="weather-info">
    <div class="" title="Sunrise">
      Time:<br/>
      <span class="value">{{convertTime(getTimeInfo.time.sunrise) | moment('MMM DD, YYYY HH:mm') }}</span>
    </div>
    <div class="" title="Sunset">
      Sunset:<br>
      <span class="value">{{convertTime(getTimeInfo.time.sunset) | moment('MMM DD, YYYY HH:mm') }}</span>
    </div>
  </div>
</template>

<script>
require('vue-moment');
import {   } from "vue-feather-icons";
import { mapGetters } from "vuex";

export default {
  components: {
  },
  computed:{
    ...mapGetters(["getTimeInfo"])
  },
  methods:{
    convertTime(timestamp){
      if(typeof timestamp !== 'undefined'){
        return timestamp * 1000;
       // console.log(moment().format('MMM DD, YYYY HH:mm'));
       // return moment(myDate, 'x').format('MMM DD, YYYY HH:mm');
      }
      
    }
  }
};
</script>

<style lang="less" scoped>
.weather-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-top: 2px solid fade(black, 10);
  padding-top: 20px;
  .weather-item {
    display: flex;
    align-items: center;
    color: var(--darkColor);
    .value {
      margin-left: 5px;
      font-weight: 500;
    }
  }
}
</style>
