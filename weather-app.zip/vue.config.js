module.exports = {
  publicPath: "/public/",
};
